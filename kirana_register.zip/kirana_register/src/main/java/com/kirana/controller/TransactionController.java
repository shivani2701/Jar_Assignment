package com.kirana.controller;

import com.kirana.model.Transaction;
import com.kirana.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

	@Autowired
    private TransactionService transactionService;

    @PostMapping
    public ResponseEntity<Transaction> recordTransaction(@RequestBody Transaction txn) {
        return ResponseEntity.ok(transactionService.addTransaction(txn));
    }

}
