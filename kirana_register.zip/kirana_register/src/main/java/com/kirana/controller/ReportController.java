package com.kirana.controller;

import com.kirana.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

	 @Autowired
	    private ReportService reportService;

	    @GetMapping("/weekly")
	    public ResponseEntity<Map<String, Double>> getWeeklyReport() {
	        Date startDate = ... // Calculate weekly start date
	        Date endDate = ...   // Calculate weekly end date

	        double totalCredits = reportService.getTotalCredits(startDate, endDate);
	        double totalDebits = reportService.getTotalDebits(startDate, endDate);

	        Map<String, Double> report = new HashMap<>();
	        report.put("credits", totalCredits);
	        report.put("debits", totalDebits);
	        report.put("netFlow", totalCredits - totalDebits);

	        return ResponseEntity.ok(report);
	    }
}
