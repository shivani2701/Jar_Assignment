package com.kirana.service;

import com.kirana.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class ReportService {
	@Autowired
    private TransactionRepository transactionRepository;

    public double getTotalCredits(Date start, Date end) {
        return transactionRepository.findByDateBetween(start, end).stream()
                .filter(txn -> "credit".equals(txn.getType()))
                .mapToDouble(txn -> txn.getAmount())
                .sum();
    }

    public double getTotalDebits(Date start, Date end) {
        return transactionRepository.findByDateBetween(start, end).stream()
                .filter(txn -> "debit".equals(txn.getType()))
                .mapToDouble(txn -> txn.getAmount())
                .sum();
    }
}
