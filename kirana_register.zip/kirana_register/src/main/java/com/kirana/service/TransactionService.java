package com.kirana.service;

import com.kirana.model.Transaction;
import com.kirana.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class TransactionService {

	@Autowired
    private TransactionRepository transactionRepository;

    public Transaction addTransaction(Transaction txn) {
        return transactionRepository.save(txn);
    }

    public List<Transaction> getTransactionsForPeriod(Date start, Date end) {
        return transactionRepository.findByDateBetween(start, end);
    }
}
